SAVOR - Modern Dining Experience
Frontend project (HTML, CSS, JavaScript). No backend or database.

HOW TO RUN
1. Unzip the folder completely (do not open files from inside the zip).
2. Double-click index.html to open it in Chrome, Edge or Firefox.
3. Keep the folder structure exactly as it is:
     index.html
     css/style.css
     js/script.js
   If you only want a single file, open savor-standalone.html instead
   (same website, with CSS and JavaScript built in).

NOTES
- Food photos and fonts load from the internet (Unsplash, Google Fonts).
  Offline, the site still works and shows styled placeholders.
- To change a dish, edit the MENU array at the top of js/script.js.
