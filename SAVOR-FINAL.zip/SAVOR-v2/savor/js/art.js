/* ==========================================================
   SAVOR – dish artwork
   Draws a dark, warm-toned illustration for every dish so the
   menu always has a matching image that suits the site colours.
   Real photos placed in /images override these (see README).
   ========================================================== */
(function () {
  "use strict";

  const GOLD = "#b8924a";

  const DEFS = `<defs>
    <radialGradient id="bg" cx="50%" cy="45%" r="75%"><stop offset="0" stop-color="#4a2f20"/><stop offset="1" stop-color="#1a110c"/></radialGradient>
    <radialGradient id="vg" cx="50%" cy="50%" r="70%"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".45"/></radialGradient>
    <radialGradient id="pl" cx="45%" cy="40%" r="70%"><stop offset="0" stop-color="#3b312b"/><stop offset="1" stop-color="#211a16"/></radialGradient>
    <filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="6"/></filter>
    <filter id="sb" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3"/></filter>
  </defs>`;

  const frame = (inner, zoom = 1.12) =>
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300">${DEFS}<rect width="400" height="300" fill="url(#bg)"/><g transform="translate(200 150) scale(${zoom}) translate(-200 -150)">${inner}</g><rect width="400" height="300" fill="url(#vg)"/></svg>`;

  function rng(seed) {
    let s = seed >>> 0 || 1;
    return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  }

  /* ---------- shared pieces ---------- */
  const plate = (r = 112) =>
    `<ellipse cx="205" cy="164" rx="${r}" ry="${r * 0.95}" fill="#000" opacity=".45" filter="url(#sh)"/>
     <circle cx="200" cy="150" r="${r}" fill="url(#pl)" stroke="${GOLD}" stroke-opacity=".55" stroke-width="2"/>
     <circle cx="200" cy="150" r="${r - 16}" fill="none" stroke="${GOLD}" stroke-opacity=".22"/>`;

  const leaf = (x, y, rot, c = "#5f8a3a") =>
    `<ellipse cx="${x}" cy="${y}" rx="8" ry="3.4" fill="${c}" transform="rotate(${rot} ${x} ${y})"/>`;

  const lemon = (x, y, rot = -20) =>
    `<g transform="translate(${x} ${y}) rotate(${rot})"><path d="M-24 0A24 24 0 0 1 24 0Z" fill="#b99a2e"/><path d="M-20 0A20 20 0 0 1 20 0Z" fill="#dcc875"/>
     <path d="M0 0V-20M0 0L-14-14M0 0L14-14" stroke="#b99a2e" stroke-width="1.5"/></g>`;

  const chutney = (x, y, r = 17, c = "#4e7a2f") =>
    `<circle cx="${x}" cy="${y}" r="${r}" fill="#2a1f19" stroke="${GOLD}" stroke-opacity=".5"/><circle cx="${x}" cy="${y}" r="${r - 4}" fill="${c}"/><circle cx="${x - 4}" cy="${y - 4}" r="${r / 4}" fill="#fff" opacity=".12"/>`;

  const onionRing = (x, y, r, rot = 0) =>
    `<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r * 0.8}" fill="none" stroke="#9a5d7c" stroke-width="3" transform="rotate(${rot} ${x} ${y})"/>`;

  /* ---------- skewer pieces ---------- */
  function piece(type, x, y, rot, s) {
    const h = s / 2;
    const g = (i) => `<g transform="translate(${x} ${y}) rotate(${rot})">${i}</g>`;
    switch (type) {
      case "paneer":
        return g(`<rect x="${-h}" y="${-h}" width="${s}" height="${s}" rx="${s * .2}" fill="#cf7a33"/><rect x="${-h + 3}" y="${-h + 3}" width="${s - 6}" height="${s * .35}" rx="3" fill="#e6a45a" opacity=".45"/><circle cx="${-h * .4}" cy="${h * .3}" r="2.4" fill="#4a2410" opacity=".7"/><circle cx="${h * .35}" cy="${-h * .1}" r="2" fill="#4a2410" opacity=".7"/>`);
      case "capsicum":
        return g(`<rect x="${-h}" y="${-h}" width="${s}" height="${s * .9}" rx="5" fill="#587f36"/><rect x="${-h + 3}" y="${-h + 3}" width="${s - 6}" height="${s * .3}" rx="3" fill="#86ab55" opacity=".5"/>`);
      case "onion":
        return g(`<rect x="${-h}" y="${-h}" width="${s}" height="${s * .9}" rx="6" fill="#8d5273"/><path d="M${-h + 5} ${-h + 6}h${s - 10}M${-h + 5} 0h${s - 10}" stroke="#c28aa6" stroke-width="2" opacity=".6"/>`);
      case "mushroom":
        return g(`<circle r="${h}" fill="#a97c52"/><ellipse cx="-2" cy="-3" rx="${h * .65}" ry="${h * .5}" fill="#c49a6c"/><circle cx="${h * .3}" cy="${h * .3}" r="2.4" fill="#a8391f"/><circle cx="${-h * .4}" cy="${h * .25}" r="2" fill="#a8391f"/>`);
      case "chicken":
        return g(`<rect x="${-h}" y="${-h * .85}" width="${s}" height="${s * .85}" rx="${s * .3}" fill="#dcc08a"/><rect x="${-h + 4}" y="${-h * .85 + 3}" width="${s - 8}" height="${s * .25}" rx="4" fill="#efdcae" opacity=".5"/><circle cx="${-h * .35}" cy="${h * .15}" r="2.6" fill="#7a4a22" opacity=".8"/><circle cx="${h * .4}" cy="${-h * .2}" r="2" fill="#7a4a22" opacity=".8"/>`);
      case "tomato":
        return g(`<circle r="${h * .9}" fill="#a93724"/><circle cx="${-h * .3}" cy="${-h * .3}" r="${h * .25}" fill="#d9654a" opacity=".6"/>`);
    }
    return "";
  }

  function skewers(types) {
    const ends = [[124, 163, 276, 87], [124, 213, 276, 137]];
    let out = "";
    ends.forEach(([x1, y1, x2, y2], row) => {
      const dx = x2 - x1, dy = y2 - y1;
      out += `<line x1="${x1 - dx * .06}" y1="${y1 - dy * .06}" x2="${x2 + dx * .06}" y2="${y2 + dy * .06}" stroke="#b9b2a6" stroke-width="3" stroke-linecap="round"/>`;
      for (let i = 0; i < 5; i++) {
        const t = (i + .5) / 5;
        const type = types[(i + row) % types.length];
        out += piece(type, x1 + dx * t, y1 + dy * t, -27, 28);
      }
    });
    return out;
  }

  const prawn = (x, y, rot, s = 1) =>
    `<g transform="translate(${x} ${y}) rotate(${rot}) scale(${s})">
      <path d="M-30 18C-34-22 22-34 34-2C40 14 28 26 14 24" fill="none" stroke="#c9552b" stroke-width="15" stroke-linecap="round"/>
      <path d="M-30 18C-34-22 22-34 34-2C40 14 28 26 14 24" fill="none" stroke="#e8935a" stroke-width="15" stroke-linecap="round" stroke-dasharray="3 8" opacity=".55"/>
      <path d="M14 24l17 9-5-19z" fill="#a73f1d"/><circle cx="-30" cy="16" r="2.8" fill="#24100a"/></g>`;

  /* ---------- starters ---------- */
  function paneerTikka() { return frame(plate() + skewers(["paneer", "capsicum", "onion"]) + lemon(150, 96) + chutney(262, 216)); }
  function mushroomTikka() { return frame(plate() + skewers(["mushroom", "capsicum", "tomato"]) + lemon(150, 96) + chutney(262, 216)); }
  function chickenMalai() { return frame(plate() + skewers(["chicken", "onion", "capsicum"]) + lemon(150, 96) + chutney(262, 216)); }

  function patties(fill, light, dots) {
    const r = rng(7);
    let out = plate();
    [[160, 116], [240, 116], [160, 184], [240, 184]].forEach(([x, y]) => {
      out += `<circle cx="${x + 3}" cy="${y + 5}" r="33" fill="#000" opacity=".35"/><circle cx="${x}" cy="${y}" r="32" fill="${fill}"/><circle cx="${x - 5}" cy="${y - 6}" r="22" fill="${light}" opacity=".35"/>`;
      for (let i = 0; i < 16; i++) {
        const a = r() * 6.28, d = r() * 26;
        out += `<circle cx="${(x + Math.cos(a) * d).toFixed(1)}" cy="${(y + Math.sin(a) * d).toFixed(1)}" r="${(1.2 + r() * 1.6).toFixed(1)}" fill="${dots}" opacity=".7"/>`;
      }
    });
    return out + chutney(200, 150, 15);
  }
  const haraBhara = () => frame(patties("#5b8239", "#8cb25c", "#2f4a1c"));
  const dahiKebab = () => frame(patties("#c9954d", "#ecc481", "#7a4a1c"));

  function muttonSeekh() {
    let out = plate();
    [[200, 108, -6], [200, 150, 2], [200, 192, -3]].forEach(([x, y, rot]) => {
      out += `<g transform="translate(${x} ${y}) rotate(${rot})"><rect x="-72" y="-12" width="144" height="26" rx="13" fill="#000" opacity=".3" transform="translate(3 5)"/><rect x="-72" y="-13" width="144" height="26" rx="13" fill="#8e3f24"/><rect x="-66" y="-10" width="132" height="8" rx="4" fill="#c06a45" opacity=".45"/>`;
      for (let i = -56; i <= 56; i += 14) out += `<path d="M${i} -10l5 20" stroke="#4a1d0e" stroke-width="2" opacity=".5"/>`;
      out += `</g>`;
    });
    return frame(out + onionRing(262, 74, 12, 20) + onionRing(272, 82, 10, -10) + chutney(138, 222, 14) + leaf(160, 76, 30));
  }

  function fishFry() {
    const fillet = (x, y, rot, s) =>
      `<g transform="translate(${x} ${y}) rotate(${rot}) scale(${s})"><path d="M-52 0C-40-26 20-30 48-8L64-22V22L48 6C20 28-40 24-52 0Z" fill="#000" opacity=".3" transform="translate(3 5)"/>
       <path d="M-52 0C-40-26 20-30 48-8L64-22V22L48 6C20 28-40 24-52 0Z" fill="#c9832f"/><path d="M-40 -6C-20-20 10-20 36-6" fill="none" stroke="#e8b062" stroke-width="5" opacity=".5"/>
       <circle cx="-30" cy="-4" r="3" fill="#3a1d0b" opacity=".8"/><circle cx="-8" cy="4" r="2" fill="#7a4a1c" opacity=".8"/><circle cx="14" cy="-2" r="2.4" fill="#7a4a1c" opacity=".8"/></g>`;
    return frame(plate() + fillet(178, 100, -8, 1) + fillet(205, 152, 6, 1) + fillet(178, 204, -4, .95) + lemon(274, 214) + leaf(282, 90, 40, "#6aa04a") + leaf(292, 98, -20, "#6aa04a"));
  }

  const prawnTandoori = () => frame(plate() + prawn(148, 112, -20) + prawn(238, 108, 15) + prawn(152, 192, 170) + prawn(240, 192, 195) + prawn(196, 150, 0, .9) + lemon(282, 66, 30));

  /* ---------- curries ---------- */
  function scatter(n, radius, seed) {
    const r = rng(seed), out = [{ x: 200, y: 152, rot: r() * 90 }];
    for (let i = 0; i < n - 1; i++) {
      const a = (i / (n - 1)) * 6.283 + r() * .5;
      out.push({ x: 200 + Math.cos(a) * radius, y: 152 + Math.sin(a) * radius, rot: r() * 180 });
    }
    return out;
  }

  function curryItem(type, p) {
    const g = (i) => `<g transform="translate(${p.x.toFixed(1)} ${p.y.toFixed(1)}) rotate(${p.rot.toFixed(0)})">${i}</g>`;
    switch (type) {
      case "paneer": return g(`<rect x="-11" y="-11" width="22" height="22" rx="4" fill="#ecd9a6" stroke="#c9b07a"/><rect x="-8" y="-8" width="16" height="5" rx="2" fill="#fff" opacity=".25"/>`);
      case "mush": return g(`<ellipse rx="16" ry="11" fill="#9b7448"/><ellipse cx="-2" cy="-2" rx="11" ry="7" fill="#c19a6b"/><rect x="-3" y="4" width="6" height="8" rx="2" fill="#d8bf97"/>`);
      case "chicken": return g(`<path d="M-16 0C-16-12 12-14 17-3C20 9 2 14-10 10C-15 8-16 4-16 0Z" fill="#cf7f45" stroke="#8f4a22"/><circle cx="-4" cy="-3" r="2.4" fill="#6b3216"/><circle cx="7" cy="2" r="2" fill="#6b3216"/>`);
      case "mutton": return g(`<path d="M-15-4L-4-13L13-8L16 5L3 13L-12 9Z" fill="#6e3220" stroke="#a65a3b" stroke-width="1.5"/><circle cx="2" cy="0" r="3" fill="#c7a58a" opacity=".6"/>`);
      case "fish": return g(`<rect x="-15" y="-10" width="30" height="20" rx="6" fill="#ead9b3" stroke="#c6b080"/><path d="M-8-4h16M-9 2h16" stroke="#c6b080" stroke-width="1.6"/>`);
      case "prawn": return `<g transform="translate(${p.x.toFixed(1)} ${p.y.toFixed(1)}) rotate(${p.rot.toFixed(0)}) scale(.55)"><path d="M-30 18C-34-22 22-34 34-2C40 14 28 26 14 24" fill="none" stroke="#e0703f" stroke-width="15" stroke-linecap="round"/><path d="M14 24l17 9-5-19z" fill="#c4562a"/></g>`;
    }
    return "";
  }

  function bowl(curry, glow, itemType, n, seed, extra = "") {
    let out = plate()
      + `<circle cx="200" cy="150" r="88" fill="#6b4421" stroke="${GOLD}" stroke-width="2.5"/><circle cx="200" cy="150" r="80" fill="#3a2414"/>
         <radialGradient id="cu" cx="45%" cy="40%" r="70%"><stop offset="0" stop-color="${glow}"/><stop offset="1" stop-color="${curry}"/></radialGradient>
         <circle cx="200" cy="150" r="74" fill="url(#cu)"/>`;
    if (itemType) scatter(n, 38, seed).forEach((p) => { out += curryItem(itemType, p); });
    out += extra;
    out += `<path d="M168 128a36 36 0 0 1 56-8" fill="none" stroke="#f1e2bd" stroke-width="5" stroke-linecap="round" opacity=".7"/><path d="M224 120a22 22 0 0 0-34 4" fill="none" stroke="#f1e2bd" stroke-width="3" stroke-linecap="round" opacity=".5"/>`;
    out += leaf(190, 142, 20) + leaf(204, 148, -40) + leaf(212, 138, 70) + leaf(196, 156, 110);
    out += `<path d="M236 176l16 4" stroke="#b8321f" stroke-width="4" stroke-linecap="round"/><path d="M148 170l-14-6" stroke="#4f8a3a" stroke-width="4" stroke-linecap="round"/>`;
    return frame(out);
  }

  const paneerButter = () => bowl("#bf5a1c", "#df8a3c", "paneer", 6, 3);
  const kadaiMushroom = () => bowl("#8f3a1c", "#b8602d", "mush", 6, 5,
    `<rect x="236" y="120" width="26" height="6" rx="3" fill="#6f9a3f" transform="rotate(25 249 123)"/><rect x="148" y="150" width="26" height="6" rx="3" fill="#6f9a3f" transform="rotate(-30 161 153)"/>`);
  const butterChicken = () => bowl("#b44218", "#d8702e", "chicken", 6, 9);
  const roganJosh = () => bowl("#7d2412", "#a63e22", "mutton", 6, 11);
  const goanFish = () => bowl("#c98a24", "#e6b44b", "fish", 5, 13,
    `<circle cx="160" cy="130" r="4" fill="#b8321f"/><circle cx="238" cy="172" r="4" fill="#b8321f"/>`);
  const prawnMasala = () => bowl("#9b3a1a", "#c4602f", "prawn", 6, 15);

  function dalMakhani() {
    const r = rng(21);
    let dots = "";
    for (let i = 0; i < 70; i++) {
      const a = r() * 6.28, d = Math.sqrt(r()) * 66;
      dots += `<ellipse cx="${(200 + Math.cos(a) * d).toFixed(1)}" cy="${(150 + Math.sin(a) * d).toFixed(1)}" rx="3.4" ry="2.4" fill="#6b3c22" opacity=".8" transform="rotate(${(r() * 180).toFixed(0)} ${(200 + Math.cos(a) * d).toFixed(1)} ${(150 + Math.sin(a) * d).toFixed(1)})"/>`;
    }
    return bowl("#34190e", "#5a2f1a", null, 0, 0,
      dots + `<rect x="206" y="138" width="22" height="16" rx="4" fill="#e3c25c" transform="rotate(-10 217 146)"/><rect x="209" y="140" width="16" height="5" rx="2" fill="#f4e0a0" opacity=".6" transform="rotate(-10 217 146)"/>`);
  }

  function vegBiryani() {
    const r = rng(33);
    const cols = ["#cdb677", "#e6d6a2", "#d9c48a", "#d9822b", "#c7ac66"];
    let out = plate() + `<circle cx="200" cy="150" r="82" fill="#2d2019" stroke="${GOLD}" stroke-opacity=".5"/><circle cx="200" cy="150" r="74" fill="#b99f63"/>`;
    for (let i = 0; i < 190; i++) {
      const a = r() * 6.28, d = Math.sqrt(r()) * 70, x = 200 + Math.cos(a) * d, y = 150 + Math.sin(a) * d, rot = (r() * 180).toFixed(0);
      out += `<rect x="${(x - 5).toFixed(1)}" y="${(y - 1.2).toFixed(1)}" width="10" height="2.6" rx="1.3" fill="${cols[Math.floor(r() * cols.length)]}" transform="rotate(${rot} ${x.toFixed(1)} ${y.toFixed(1)})"/>`;
    }
    for (let i = 0; i < 26; i++) {
      const a = r() * 6.28, d = Math.sqrt(r()) * 62;
      out += `<circle cx="${(200 + Math.cos(a) * d).toFixed(1)}" cy="${(150 + Math.sin(a) * d).toFixed(1)}" r="${(2 + r() * 2).toFixed(1)}" fill="${i % 3 ? "#5a3416" : i % 2 ? "#7ba24a" : "#d36b22"}"/>`;
    }
    return frame(out + leaf(180, 124, 30) + leaf(224, 140, -50) + leaf(196, 176, 80) + leaf(170, 152, 10));
  }

  /* ---------- desserts ---------- */
  function fondant() {
    return frame(plate()
      + `<circle cx="182" cy="158" r="56" fill="#000" opacity=".3" transform="translate(3 5)"/><circle cx="180" cy="154" r="56" fill="#3a1d12"/><circle cx="180" cy="154" r="48" fill="#4a2517"/>
         <path d="M172 144C190 138 204 150 200 164C196 178 176 180 168 168C162 160 164 148 172 144Z" fill="#26120a"/><path d="M200 164C214 178 212 196 200 200" fill="none" stroke="#3a1a0e" stroke-width="9" stroke-linecap="round"/>
         <circle cx="248" cy="128" r="29" fill="#000" opacity=".3" transform="translate(3 4)"/><circle cx="248" cy="126" r="28" fill="#d6c7a2"/><circle cx="240" cy="118" r="11" fill="#efe3c3" opacity=".5"/>
         <circle cx="148" cy="108" r="8" fill="#9c2638"/><circle cx="160" cy="100" r="7" fill="#b03448"/>` + leaf(250, 94, 30, "#5f8a3a") + leaf(262, 98, -10, "#5f8a3a"));
  }

  function pannaCotta() {
    return frame(plate()
      + `<circle cx="200" cy="152" r="70" fill="#6e1f2d" opacity=".4"/><circle cx="203" cy="157" r="52" fill="#000" opacity=".3"/><circle cx="200" cy="152" r="52" fill="#d9ccaa"/><circle cx="190" cy="140" r="30" fill="#efe3c3" opacity=".35"/>
         <path d="M168 138C176 116 220 114 232 138C240 156 224 168 204 164C180 172 160 156 168 138Z" fill="#8b2338"/><path d="M180 134C190 124 214 126 220 138" fill="none" stroke="#c4506a" stroke-width="4" opacity=".7" stroke-linecap="round"/>
         <circle cx="192" cy="146" r="7" fill="#5e1424"/><circle cx="214" cy="150" r="6" fill="#a02a42"/>` + leaf(214, 128, -30, "#5f8a3a") + leaf(224, 134, 20, "#5f8a3a"));
  }

  function tiramisu() {
    const layers = [["#3d2315", 16], ["#dccca4", 26], ["#7d5232", 18], ["#dccca4", 26], ["#7d5232", 18]];
    let y = 100, out = plate() + `<rect x="133" y="206" width="140" height="8" rx="4" fill="#000" opacity=".4" filter="url(#sb)"/>`;
    layers.forEach(([c, h], i) => {
      out += `<rect x="130" y="${y}" width="140" height="${h}" fill="${c}"${i === 0 ? ' rx="4"' : ""}/>`;
      if (c === "#7d5232") out += `<path d="M136 ${y + h / 2}h128" stroke="#4e301a" stroke-width="2" stroke-dasharray="3 6" opacity=".7"/>`;
      if (c === "#dccca4") out += `<rect x="130" y="${y}" width="140" height="4" fill="#fff" opacity=".12"/>`;
      y += h;
    });
    const r = rng(41);
    for (let i = 0; i < 40; i++) out += `<circle cx="${(134 + r() * 132).toFixed(1)}" cy="${(100 + r() * 14).toFixed(1)}" r="1.4" fill="#6b4226" opacity=".8"/>`;
    return frame(out + `<ellipse cx="170" cy="96" rx="9" ry="5" fill="#24130a"/><ellipse cx="190" cy="94" rx="9" ry="5" fill="#24130a" transform="rotate(20 190 94)"/>`);
  }

  function pancakes() {
    let out = plate();
    [194, 176, 158, 140].forEach((y, i) => {
      out += `<ellipse cx="200" cy="${y + 7}" rx="80" ry="18" fill="#7a4a1e"/><ellipse cx="200" cy="${y}" rx="80" ry="18" fill="${i % 2 ? "#c58a40" : "#b97c33"}"/><ellipse cx="200" cy="${y - 4}" rx="74" ry="15" fill="#d6a054"/>`;
    });
    out += `<ellipse cx="200" cy="134" rx="62" ry="12" fill="#d3961c" opacity=".9"/><path d="M146 136c0 16 8 16 8 6s8-10 8 0 8 24 14 4 12-8 14 6 10 10 12-4 8-6 8 4 8-8 6-10 6 0" fill="#d3961c" opacity=".9"/>
            <rect x="188" y="116" width="26" height="16" rx="4" fill="#e6d189" transform="rotate(-8 200 124)"/>
            <circle cx="160" cy="130" r="8" fill="#363a68"/><circle cx="172" cy="122" r="7" fill="#9a2a42"/><circle cx="232" cy="124" r="8" fill="#363a68"/><circle cx="244" cy="132" r="7" fill="#9a2a42"/><circle cx="224" cy="116" r="6" fill="#4a4f80"/>`;
    return frame(out + leaf(206, 108, -20, "#5f8a3a") + leaf(218, 112, 30, "#5f8a3a"));
  }

  /* ---------- beverages ---------- */
  const stage = (inner) => frame(
    `<circle cx="200" cy="150" r="115" fill="${GOLD}" opacity=".1"/><rect x="0" y="238" width="400" height="62" fill="#120c08" opacity=".55"/><ellipse cx="200" cy="240" rx="72" ry="10" fill="#000" opacity=".5" filter="url(#sb)"/>${inner}`, 1);

  const glassOutline = (d) => `<path d="${d}" fill="rgba(255,255,255,.07)" stroke="#d8c9a8" stroke-opacity=".55" stroke-width="2.5" stroke-linejoin="round"/>`;
  const ice = (x, y, s, rot) => `<rect x="${x - s / 2}" y="${y - s / 2}" width="${s}" height="${s}" rx="6" fill="rgba(225,235,240,.22)" stroke="rgba(255,255,255,.35)" transform="rotate(${rot} ${x} ${y})"/>`;

  function oldFashioned() {
    return stage(`<path d="M150 150H250L244 230H156Z" fill="#a85a1c"/><path d="M150 150H250L249 168H151Z" fill="#c77c33" opacity=".8"/>`
      + ice(200, 178, 52, 8) + glassOutline("M146 112H254L244 232H156Z")
      + `<path d="M230 112c14-12 30-4 22 10" fill="none" stroke="#d9822b" stroke-width="7" stroke-linecap="round"/><rect x="156" y="118" width="6" height="104" rx="3" fill="#fff" opacity=".1"/>`
      + `<path d="M186 96c-12-16 12-26 0-44M206 96c-12-16 12-26 0-44M226 92c-10-14 10-22 0-36" fill="none" stroke="#e6e0d6" stroke-opacity=".22" stroke-width="6" stroke-linecap="round" filter="url(#sb)"/>`);
  }

  function coldBrew() {
    return stage(`<defs><linearGradient id="lq" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#24130b"/><stop offset=".5" stop-color="#5b3a22"/><stop offset="1" stop-color="#c4b384"/></linearGradient></defs><path d="M160 66H240L232 232H168Z" fill="url(#lq)"/>`
      + ice(196, 110, 34, 10) + ice(214, 150, 32, -8) + ice(194, 192, 34, 6)
      + glassOutline("M158 62H242L233 234H167Z")
      + `<line x1="216" y1="34" x2="198" y2="200" stroke="#cfc2a0" stroke-width="6" stroke-linecap="round"/><g transform="translate(244 68)"><circle r="22" fill="#c9782a"/><circle r="17" fill="#e0a257"/><path d="M0 0V-17M0 0L-15-9M0 0L15-9M0 0L-9 14M0 0L9 14" stroke="#c9782a" stroke-width="2"/></g>`
      + `<rect x="167" y="72" width="6" height="150" rx="3" fill="#fff" opacity=".1"/>`);
  }

  function pomegranate() {
    const r = rng(51);
    let arils = "";
    for (let i = 0; i < 16; i++) arils += `<circle cx="${(172 + r() * 56).toFixed(1)}" cy="${(205 + r() * 20).toFixed(1)}" r="3.6" fill="${i % 2 ? "#c43a52" : "#8c1c33"}"/>`;
    return stage(`<defs><linearGradient id="lq" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b32a45"/><stop offset="1" stop-color="#5e1228"/></linearGradient></defs><path d="M160 82H240L232 232H168Z" fill="url(#lq)"/>`
      + ice(198, 120, 34, 10) + ice(214, 160, 32, -10) + arils
      + glassOutline("M158 78H242L233 234H167Z")
      + leaf(190, 74, -60, "#4f8a4a") + leaf(204, 70, 80, "#4f8a4a") + leaf(214, 76, 20, "#4f8a4a") + leaf(196, 62, -20, "#5f9a58") + leaf(208, 62, 40, "#5f9a58")
      + `<g transform="translate(240 86)"><circle r="20" fill="#5f8a3a"/><circle r="16" fill="#a5c26a"/><path d="M0 0V-16M0 0L-14-8M0 0L14-8M0 0L-9 13M0 0L9 13" stroke="#5f8a3a" stroke-width="2"/></g>`
      + `<rect x="167" y="88" width="6" height="134" rx="3" fill="#fff" opacity=".1"/>`);
  }

  function lassi() {
    return stage(`<defs><linearGradient id="lq" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e9ddbf"/><stop offset="1" stop-color="#cdb98f"/></linearGradient></defs><path d="M153 112H247L240 232H160Z" fill="url(#lq)"/><path d="M153 112H247L246 126H154Z" fill="#f1e8d0"/>`
      + `<path d="M172 150c20 14 36-8 56 6" fill="none" stroke="#d9a0b0" stroke-width="7" stroke-linecap="round" opacity=".45"/>`
      + glassOutline("M150 108H250L242 234H158Z")
      + [[176, 100, 20], [190, 96, -30], [206, 98, 40], [222, 100, -10], [198, 104, 70], [214, 94, 10]].map(([x, y, a]) => `<path d="M${x} ${y}q6-12 12-4" fill="none" stroke="#d9822b" stroke-width="2.2" stroke-linecap="round" transform="rotate(${a} ${x} ${y})"/>`).join("")
      + `<ellipse cx="190" cy="112" rx="12" ry="6" fill="#b85d7c" transform="rotate(-20 190 112)"/><ellipse cx="214" cy="110" rx="11" ry="5.5" fill="#c4708c" transform="rotate(25 214 110)"/><ellipse cx="202" cy="104" rx="9" ry="5" fill="#a64d6d"/>`
      + `<circle cx="172" cy="112" r="2.6" fill="#7ba24a"/><circle cx="228" cy="112" r="2.6" fill="#7ba24a"/><circle cx="182" cy="118" r="2.2" fill="#7ba24a"/><circle cx="222" cy="119" r="2.2" fill="#7ba24a"/>`
      + `<rect x="160" y="118" width="6" height="104" rx="3" fill="#fff" opacity=".1"/>`);
  }

  /* ---------- registry ---------- */
  const ART = {
    paneerTikka, mushroomTikka, haraBhara, dahiKebab, chickenMalai, muttonSeekh, fishFry, prawnTandoori,
    paneerButter, kadaiMushroom, dalMakhani, vegBiryani, butterChicken, roganJosh, goanFish, prawnMasala,
    fondant, pannaCotta, tiramisu, pancakes, oldFashioned, coldBrew, pomegranate, lassi
  };

  /* Pick artwork for dishes added by the user, based on category and type */
  function pickKey(category, veg) {
    if (category === "starters") return veg ? "haraBhara" : "muttonSeekh";
    if (category === "mains") return veg ? "paneerButter" : "butterChicken";
    if (category === "desserts") return "fondant";
    return "pomegranate";
  }

  const cache = {};
  function uri(key) {
    if (!cache[key]) {
      const svg = (ART[key] || ART.fondant)();
      cache[key] = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
    }
    return cache[key];
  }

  window.SavorArt = { uri, pickKey, keys: Object.keys(ART) };
})();
