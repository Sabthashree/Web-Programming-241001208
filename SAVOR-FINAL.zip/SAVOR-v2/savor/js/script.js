/* ==========================================================
   SAVOR – interactions (Indian menu edition)
   ========================================================== */
(function () {
  "use strict";

  document.documentElement.classList.add("js");

  /* ---------- Menu data (Indian dishes) ---------- */
  const CATEGORY_LABELS = {
    starters: "Starters",
    mains: "Main Course",
    desserts: "Desserts",
    beverages: "Beverages"
  };

  /* artKey maps to window.SavorArt.uri(key) from art.js */
  const MENU = [
    /* ── Starters (Dishes 1 – 6) ───────────────────────── */
    {
      id: 1, category: "starters", veg: false, featured: false, price: 480,
      name: "Spicy Chicken Wings",
      desc: "Crisp drumettes and wings tossed in a fiery herb and chilli glaze, served with a cooling dip.",
      ingredients: "Chicken wings, kashmiri chilli glaze, garlic, coriander, sour cream dip",
      note: "Medium spice level. Served with lemon and dip.",
      image: "images/01_spicy_chicken_wings.jpg",
      artKey: "chickenMalai"
    },
    {
      id: 2, category: "starters", veg: true, featured: false, price: 380,
      name: "Bruschetta",
      desc: "Toasted artisan sourdough rubbed with garlic, topped with heirloom tomatoes, basil and olive oil.",
      ingredients: "Sourdough bread, heirloom tomatoes, fresh basil, garlic, extra virgin olive oil",
      note: "Vegetarian and dairy-free.",
      image: "images/02_bruschetta.jpg",
      artKey: "haraBhara"
    },
    {
      id: 3, category: "starters", veg: false, featured: false, price: 540,
      name: "Calamari",
      desc: "Tender calamari rings dusted in seasoned crumb, flash-fried golden and served with garlic aioli.",
      ingredients: "Fresh squid rings, cracked black pepper, garlic aioli, lemon wedge",
      note: "Contains shellfish. Served with lemon wedge.",
      image: "images/03_calamari.jpg",
      artKey: "fishFry"
    },
    {
      id: 4, category: "starters", veg: true, featured: false, price: 420,
      name: "Stuffed Mushrooms",
      desc: "Oven-baked button mushroom caps packed with seasoned cheese, fine herbs and garlic butter.",
      ingredients: "Button mushrooms, cream cheese, garlic, parsley, thyme, breadcrumbs",
      note: "Contains dairy and gluten.",
      image: "images/04_stuffed_mushrooms.jpg",
      artKey: "mushroomTikka"
    },
    {
      id: 5, category: "starters", veg: true, featured: false, price: 360,
      name: "Spring Rolls",
      desc: "Golden-crisp hand-rolled pastry filled with shredded cabbage, carrots, bell peppers and scallions.",
      ingredients: "Pastry sheet, shredded vegetables, glass noodles, sweet chilli dipping sauce",
      note: "Served with house sweet chilli dip.",
      image: "images/05_spring_rolls.jpg",
      artKey: "dahiKebab"
    },
    {
      id: 6, category: "starters", veg: true, featured: false, price: 460,
      name: "Paneer Tikka",
      desc: "Cubes of cottage cheese marinated in tandoori spices and char-grilled in the clay oven.",
      ingredients: "Paneer, yoghurt, ginger-garlic paste, cumin, kashmiri chilli, capsicum, lemon",
      note: "Contains dairy. Served with mint chutney and lemon.",
      image: "images/06_paneer_tikka.jpg",
      artKey: "paneerTikka"
    },

    /* ── Main Course (Dishes 7 – 12) ───────────────────── */
    {
      id: 7, category: "mains", veg: false, featured: true, price: 580,
      name: "Chicken Biryani",
      desc: "Fragrant basmati rice dum-cooked with tender spiced chicken, saffron, mint and caramelised onions.",
      ingredients: "Basmati rice, chicken, saffron, mint, ghee, whole aromatic spices, caramelised onion",
      note: "Served with cooling cucumber raita and salan.",
      image: "images/07_chicken_biryani.jpg",
      artKey: "vegBiryani"
    },
    {
      id: 8, category: "mains", veg: false, featured: false, price: 620,
      name: "Butter Chicken",
      desc: "Tandoori chicken pieces folded into a satiny tomato and butter gravy, finished with fenugreek cream.",
      ingredients: "Chicken, tomato, butter, cream, cashew, kashmiri chilli, kasuri methi, cardamom",
      note: "Contains dairy and nuts. Mild to medium spice.",
      image: "images/08_butter_chicken.jpg",
      artKey: "butterChicken"
    },
    {
      id: 9, category: "mains", veg: true, featured: false, price: 380,
      name: "Dal Makhani",
      desc: "Slow-cooked overnight black lentils finished with fresh butter and cream — rich and smoky.",
      ingredients: "Black lentils, kidney beans, tomato, butter, cream, ginger, garlic, garam masala",
      note: "Contains dairy. The lentils cook for 18 hours.",
      image: "images/09_dal_makhani.jpg",
      artKey: "dalMakhani"
    },
    {
      id: 10, category: "mains", veg: true, featured: true, price: 520,
      name: "Paneer Butter Masala",
      desc: "Soft cottage cheese cubes simmered in a rich, velvety tomato-butter sauce with toasted fenugreek.",
      ingredients: "Paneer, tomato, butter, cream, cashew paste, kashmiri chilli, kasuri methi",
      note: "Contains dairy and nuts. Pairs beautifully with butter naan.",
      image: "images/10_paneer_butter_masala.jpg",
      artKey: "paneerButter"
    },
    {
      id: 11, category: "mains", veg: true, featured: false, price: 420,
      name: "Vegetable Pulao",
      desc: "Aromatic long-grain basmati gently cooked with seasonal green peas, carrots, beans and mild spices.",
      ingredients: "Basmati rice, green peas, carrots, french beans, cumin, bay leaf, ghee",
      note: "Gluten-free. Served with roasted papad and raita.",
      image: "images/11_vegetable_pulao.jpg",
      artKey: "vegBiryani"
    },
    {
      id: 12, category: "mains", veg: false, featured: false, price: 680,
      name: "Grilled Fish",
      desc: "Fresh sea fish fillet marinated in herbs, cracked pepper and olive oil, seared over open coals.",
      ingredients: "Fresh fish fillet, garlic, lemon, extra virgin olive oil, rosemary, roasted greens",
      note: "Served with charred lemon and seasonal grilled vegetables.",
      image: "images/12_grilled_fish.jpg",
      artKey: "goanFish"
    },

    /* ── Desserts (Dishes 13 – 18) ─────────────────────── */
    {
      id: 13, category: "desserts", veg: true, featured: true, price: 480,
      name: "Chocolate Lava Cake",
      desc: "Warm dark chocolate sponge with a molten flowing centre, served with fresh raspberries and mint.",
      ingredients: "70% dark chocolate, butter, cocoa, flour, sugar, vanilla bean, fresh berries",
      note: "Baked fresh to order — allow 12 minutes. Contains dairy and gluten.",
      image: "images/13_chocolate_lava_cake.jpg",
      artKey: "fondant"
    },
    {
      id: 14, category: "desserts", veg: true, featured: false, price: 460,
      name: "Cheesecake",
      desc: "Classic New York-style baked cheesecake on a buttery biscuit crumb, topped with berry compote.",
      ingredients: "Cream cheese, biscuit crumb, butter, vanilla bean, fresh blueberries, raspberry coulis",
      note: "Contains dairy and gluten.",
      image: "images/14_cheesecake.jpg",
      artKey: "pannaCotta"
    },
    {
      id: 15, category: "desserts", veg: true, featured: false, price: 340,
      name: "Gulab Jamun",
      desc: "Golden-brown milk dumpling spheres steeped in warm cardamom and rose water sugar syrup.",
      ingredients: "Khoya, paneer, cardamom, saffron, rose syrup, crushed pistachios",
      note: "Contains dairy and nuts. Served warm.",
      image: "images/15_gulab_jamun.jpg",
      artKey: "pancakes"
    },
    {
      id: 16, category: "desserts", veg: true, featured: false, price: 520,
      name: "Tiramisu",
      desc: "Espresso-soaked savoiardi ladyfingers layered with mascarpone cream and finished with cocoa dust.",
      ingredients: "Mascarpone, espresso coffee, savoiardi biscuits, cocoa powder, vanilla",
      note: "Contains dairy and gluten.",
      image: "images/16_tiramisu.jpg",
      artKey: "tiramisu"
    },
    {
      id: 17, category: "desserts", veg: true, featured: false, price: 420,
      name: "Fruit Tart",
      desc: "Crisp sweet shortcrust pastry filled with vanilla bean pastry cream, crowned with fresh berries.",
      ingredients: "Flour, butter, vanilla pastry cream, strawberries, blackberries, blueberries",
      note: "Contains dairy and gluten.",
      image: "images/17_fruit_tart.jpg",
      artKey: "pannaCotta"
    },
    {
      id: 18, category: "desserts", veg: true, featured: false, price: 360,
      name: "Kulfi",
      desc: "Traditional slow-churned Indian frozen dessert flavoured with saffron, cardamom and crushed pistachio.",
      ingredients: "Reduced whole milk, rabri, saffron, green cardamom, roasted pistachios",
      note: "Contains dairy and nuts.",
      image: "images/18_kulfi.jpg",
      artKey: "lassi"
    },

    /* ── Beverages (Dishes 19 – 24) ────────────────────── */
    {
      id: 19, category: "beverages", veg: true, featured: false, price: 280,
      name: "Iced Coffee",
      desc: "Chilled double-shot espresso poured over cold milk and ice cubes, lightly sweetened.",
      ingredients: "Espresso, cold milk, demerara syrup, ice",
      note: "Contains caffeine and dairy. Oat milk available on request.",
      image: "images/19_iced_coffee.jpg",
      artKey: "coldBrew"
    },
    {
      id: 20, category: "beverages", veg: true, featured: false, price: 320,
      name: "Mojito",
      desc: "Muddled fresh mint leaves, tart lime wedges and raw cane sugar topped with sparkling soda and crushed ice.",
      ingredients: "Fresh mint, lime juice, cane sugar, sparkling soda, crushed ice",
      note: "Refreshing virgin mojito. Dairy-free.",
      image: "images/20_mojito.jpg",
      artKey: "pomegranate"
    },
    {
      id: 21, category: "beverages", veg: true, featured: false, price: 340,
      name: "Mango Smoothie",
      desc: "Thick and luscious blend of sun-ripened Alphonso mangoes, creamy yoghurt and a touch of wild honey.",
      ingredients: "Alphonso mango pulp, yoghurt, milk, wild honey, fresh mango chunks",
      note: "Contains dairy.",
      image: "images/21_mango_smoothie.jpg",
      artKey: "lassi"
    },
    {
      id: 22, category: "beverages", veg: true, featured: false, price: 320,
      name: "Hot Chocolate",
      desc: "Rich Belgian dark chocolate melted into steamed milk, crowned with whipped cream and cocoa shavings.",
      ingredients: "Belgian dark chocolate, whole milk, whipped cream, dark cocoa shavings",
      note: "Contains dairy.",
      image: "images/22_hot_chocolate.jpg",
      artKey: "oldFashioned"
    },
    {
      id: 23, category: "beverages", veg: true, featured: false, price: 240,
      name: "Green Tea",
      desc: "Whole-leaf organic green tea steeped with fresh garden mint leaves and served piping hot in a glass cup.",
      ingredients: "Organic green tea leaves, hot water, fresh mint leaves",
      note: "Contains natural antioxidants. Sugar served on the side.",
      image: "images/23_green_tea.jpg",
      artKey: "coldBrew"
    },
    {
      id: 24, category: "beverages", veg: true, featured: false, price: 260,
      name: "Fresh Orange Juice",
      desc: "Freshly squeezed Valencia oranges served chilled with natural citrus pulp and an orange slice.",
      ingredients: "100% fresh Valencia oranges, chilled over ice",
      note: "No added sugar or preservatives.",
      image: "images/24_fresh_orange_juice.jpg",
      artKey: "pomegranate"
    }
  ];

  /* ---------- Helpers ---------- */
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const formatPrice = (n) => "₹" + n.toLocaleString("en-IN");

  function escapeHTML(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  /* Art image helper — falls back to empty string if art.js hasn't loaded */
  const artUri = (key) =>
    (window.SavorArt && window.SavorArt.uri) ? window.SavorArt.uri(key) : "";

  /* ---------- Error fallback for broken images ---------- */
  document.addEventListener("error", (e) => {
    const el = e.target;
    if (el.tagName !== "IMG") return;
    const wrap = el.closest(".img-wrap");
    if (wrap) wrap.classList.add("img-failed");
    else el.style.visibility = "hidden";
  }, true);

  /* ---------- Toasts ---------- */
  const toastRegion = $("#toastRegion");

  function showToast(message, type = "success", duration = 5000) {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.setAttribute("role", type === "error" ? "alert" : "status");
    toast.innerHTML = `<span>${escapeHTML(message)}</span><button type="button" aria-label="Dismiss notification">&times;</button>`;
    toastRegion.appendChild(toast);
    const remove = () => {
      toast.classList.add("is-leaving");
      toast.addEventListener("animationend", () => toast.remove(), { once: true });
    };
    $("button", toast).addEventListener("click", remove);
    setTimeout(remove, duration);
  }

  /* ---------- Render dish cards ---------- */
  const menuGrid = $("#menuGrid");
  const featuredGrid = $("#featuredGrid");

  const dietDot = (veg) =>
    `<i class="diet ${veg ? "diet-veg" : "diet-nonveg"}" role="img" aria-label="${veg ? "Vegetarian" : "Non-vegetarian"}"></i>`;

  function dishCardHTML(dish, index) {
    const uri = dish.image || artUri(dish.artKey);
    return `
      <article class="dish-card" style="animation-delay:${index * 50}ms" data-veg="${dish.veg}">
        <div class="img-wrap" data-label="${escapeHTML(dish.name)}">
          ${uri ? `<img src="${uri}" alt="${escapeHTML(dish.name)}">` : ""}
        </div>
        <div class="dish-body">
          <div class="dish-top">
            <h3>${dietDot(dish.veg)}<span>${escapeHTML(dish.name)}</span></h3>
            <span class="price">${formatPrice(dish.price)}</span>
          </div>
          <p class="dish-desc">${escapeHTML(dish.desc)}</p>
          <button type="button" class="link-btn" data-dish="${dish.id}" aria-label="View details for ${escapeHTML(dish.name)}">View Details</button>
        </div>
      </article>`;
  }

  function renderFeatured() {
    const items = MENU.filter((d) => d.featured);
    featuredGrid.innerHTML = items.map((dish) => {
      const uri = dish.image || artUri(dish.artKey);
      return `
        <button type="button" class="feature-card" data-dish="${dish.id}" aria-label="View details for ${escapeHTML(dish.name)}">
          <div class="img-wrap" data-label="${escapeHTML(dish.name)}">
            ${uri ? `<img src="${uri}" alt="">` : ""}
          </div>
          <div class="${dish.veg ? "feature-diet-badge veg" : "feature-diet-badge nonveg"}" aria-label="${dish.veg ? "Vegetarian" : "Non-vegetarian"}"></div>
          <div class="feature-body">
            <h3>${escapeHTML(dish.name)}</h3>
            <p>${escapeHTML(dish.desc)}</p>
            <span class="feature-price">${formatPrice(dish.price)}</span>
          </div>
        </button>`;
    }).join("");
  }

  /* ---------- Filter state & render ---------- */
  let currentCategory = "all";
  let currentDiet = "all";

  function renderMenu() {
    let items = currentCategory === "all"
      ? MENU
      : MENU.filter((d) => d.category === currentCategory);

    if (currentDiet === "veg")    items = items.filter((d) => d.veg);
    if (currentDiet === "nonveg") items = items.filter((d) => !d.veg);

    if (items.length === 0) {
      menuGrid.innerHTML = `<p class="menu-empty">No dishes match your selection.</p>`;
    } else {
      menuGrid.innerHTML = items.map(dishCardHTML).join("");
    }
  }

  renderFeatured();
  renderMenu();

  /* ---------- Category filter ---------- */
  const filterButtons = $$(".filter-btn");
  filterButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      filterButtons.forEach((b) => {
        const active = b === btn;
        b.classList.toggle("is-active", active);
        b.setAttribute("aria-pressed", String(active));
      });
      currentCategory = btn.dataset.filter;
      renderMenu();
    });
  });

  /* ---------- Diet filter ---------- */
  const dietBtns = $$(".diet-filter-btn");
  dietBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const diet = btn.dataset.diet;
      currentDiet = diet;
      dietBtns.forEach((b) => {
        b.classList.remove("is-active-all", "is-active-veg", "is-active-nonveg");
        b.setAttribute("aria-pressed", String(b === btn));
      });
      if (diet === "all")    btn.classList.add("is-active-all");
      if (diet === "veg")    btn.classList.add("is-active-veg");
      if (diet === "nonveg") btn.classList.add("is-active-nonveg");
      renderMenu();
    });
  });

  /* ---------- Dish details dialog ---------- */
  const dialog = $("#dishDialog");
  let lastTrigger = null;

  function openDish(id, trigger) {
    const dish = MENU.find((d) => d.id === Number(id));
    if (!dish) return;
    lastTrigger = trigger;

    const imgWrap = $("#dialogImg").parentElement;
    imgWrap.classList.remove("img-failed");
    imgWrap.dataset.label = dish.name;
    const uri = dish.image || artUri(dish.artKey);
    const dialogImg = $("#dialogImg");
    dialogImg.src = uri;
    dialogImg.alt = dish.name;
    $("#dialogCat").textContent = CATEGORY_LABELS[dish.category];
    $("#dialogTitle").textContent = dish.name;
    $("#dialogDiet").innerHTML = `${dietDot(dish.veg)} ${dish.veg ? "Vegetarian" : "Non-vegetarian"}`;
    $("#dialogDesc").textContent = dish.desc;
    $("#dialogIng").textContent = dish.ingredients;
    $("#dialogNote").textContent = dish.note;
    $("#dialogPrice").textContent = formatPrice(dish.price);

    if (typeof dialog.showModal === "function") dialog.showModal();
    else dialog.setAttribute("open", "");
  }

  function closeDialog() {
    if (typeof dialog.close === "function") dialog.close();
    else dialog.removeAttribute("open");
  }

  document.addEventListener("click", (e) => {
    const trigger = e.target.closest("[data-dish]");
    if (trigger) openDish(trigger.dataset.dish, trigger);
  });
  $("#dialogClose").addEventListener("click", closeDialog);
  dialog.addEventListener("click", (e) => { if (e.target === dialog) closeDialog(); });
  dialog.addEventListener("close", () => { if (lastTrigger) lastTrigger.focus(); });
  $("#dialogBook").addEventListener("click", closeDialog);

  /* ---------- Add Dish dialog ---------- */
  const addDialog = $("#addDishDialog");
  const addDishBtn = $("#addDishBtn");
  const addDishClose = $("#addDishClose");
  const addDishForm = $("#addDishForm");
  const addPreview = $("#addDishPreview");
  const addPreviewImg = $("#addDishPreviewImg");

  function openAddDish() {
    addDishForm.reset();
    addPreview.classList.remove("show");
    $$(".error-msg", addDishForm).forEach((m) => { m.textContent = ""; });
    $$(".field", addDishForm).forEach((f) => f.classList.remove("has-error"));
    if (typeof addDialog.showModal === "function") addDialog.showModal();
    else addDialog.setAttribute("open", "");
  }

  function closeAddDish() {
    if (typeof addDialog.close === "function") addDialog.close();
    else addDialog.removeAttribute("open");
  }

  addDishBtn.addEventListener("click", openAddDish);
  addDishClose.addEventListener("click", closeAddDish);
  addDialog.addEventListener("click", (e) => { if (e.target === addDialog) closeAddDish(); });

  /* Live preview when category or diet changes */
  function updateAddPreview() {
    const cat = $("#adCategory").value;
    const vegVal = document.querySelector('input[name="adVeg"]:checked');
    if (!cat || !vegVal || !window.SavorArt) { addPreview.classList.remove("show"); return; }
    const isVeg = vegVal.value === "veg";
    const key = window.SavorArt.pickKey(cat, isVeg);
    addPreviewImg.src = window.SavorArt.uri(key);
    addPreview.classList.add("show");
  }

  $("#adCategory").addEventListener("change", updateAddPreview);
  $$('input[name="adVeg"]').forEach((r) => r.addEventListener("change", updateAddPreview));

  let nextId = MENU.length + 1;

  addDishForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = $("#adName").value.trim();
    const category = $("#adCategory").value;
    const price = parseInt($("#adPrice").value, 10);
    const vegInput = document.querySelector('input[name="adVeg"]:checked');
    const desc = $("#adDesc").value.trim();

    let valid = true;

    function setErr(id, msg) {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = msg;
      const field = el.closest(".field");
      if (field) field.classList.toggle("has-error", Boolean(msg));
      valid = valid && !msg;
    }

    setErr("adNameError",     !name              ? "Enter a dish name."            : name.length < 2 ? "Name must be at least 2 characters." : "");
    setErr("adCategoryError", !category          ? "Select a category."            : "");
    setErr("adPriceError",    !price || price < 1 ? "Enter a valid price in ₹."    : "");
    setErr("adVegError",      !vegInput          ? "Select vegetarian or non-vegetarian." : "");
    setErr("adDescError",     !desc              ? "Enter a short description."     : "");

    if (!valid) return;

    const isVeg = vegInput.value === "veg";
    const key = window.SavorArt
      ? window.SavorArt.pickKey(category, isVeg)
      : (isVeg ? "haraBhara" : "muttonSeekh");

    const newDish = {
      id: nextId++,
      category,
      veg: isVeg,
      featured: false,
      price,
      name,
      desc,
      ingredients: $("#adIng").value.trim() || "Ask your server.",
      note: $("#adNote").value.trim() || "Made fresh to order.",
      artKey: key
    };

    MENU.push(newDish);
    closeAddDish();
    renderMenu();
    showToast(`"${name}" has been added to the menu.`, "success");

    /* If the new dish matches a current filter, scroll the grid into view */
    if (currentCategory === "all" || currentCategory === newDish.category) {
      menuGrid.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  });

  /* ---------- Header, mobile nav, scroll spy ---------- */
  const siteHeader = $("#siteHeader");
  const navToggle = $("#navToggle");
  const nav = $("#primaryNav");
  const navLinks = $$(".nav-link");

  function setNav(open) {
    nav.classList.toggle("is-open", open);
    siteHeader.classList.toggle("menu-open", open);
    navToggle.setAttribute("aria-expanded", String(open));
    navToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    document.body.style.overflow = open ? "hidden" : "";
  }

  navToggle.addEventListener("click", () => setNav(!nav.classList.contains("is-open")));
  $$("a", nav).forEach((a) => a.addEventListener("click", () => setNav(false)));
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && nav.classList.contains("is-open")) { setNav(false); navToggle.focus(); }
  });
  window.matchMedia("(min-width: 861px)").addEventListener("change", (e) => { if (e.matches) setNav(false); });

  const sectionIds = ["home", "menu", "about", "reservations", "contact"];
  const spyTargets = sectionIds.map((id) => document.getElementById(id));
  const toTop = $("#toTop");

  function onScroll() {
    siteHeader.classList.toggle("is-solid", window.scrollY > 40);
    toTop.hidden = window.scrollY < 600;
    const probe = window.scrollY + window.innerHeight * 0.35;
    let current = "home";
    spyTargets.forEach((section) => { if (section && section.offsetTop <= probe) current = section.id; });
    navLinks.forEach((link) => link.classList.toggle("is-active", link.getAttribute("href") === `#${current}`));
  }

  let ticking = false;
  window.addEventListener("scroll", () => {
    if (!ticking) { requestAnimationFrame(() => { onScroll(); ticking = false; }); ticking = true; }
  }, { passive: true });
  onScroll();

  toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

  /* ---------- Scroll reveal ---------- */
  const revealTargets = $$(".section-head, .about-copy, .res-intro, .res-card, .contact-info, .map-placeholder");
  revealTargets.forEach((el) => el.classList.add("reveal"));
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { entry.target.classList.add("is-visible"); observer.unobserve(entry.target); }
      });
    }, { threshold: 0.12 });
    revealTargets.forEach((el) => observer.observe(el));
  } else {
    revealTargets.forEach((el) => el.classList.add("is-visible"));
  }

  /* ---------- Reservation form ---------- */
  const form = $("#reservationForm");
  const confirmation = $("#confirmation");
  const fields = {
    name:   $("#name"),
    email:  $("#email"),
    phone:  $("#phone"),
    guests: $("#guests"),
    date:   $("#date"),
    time:   $("#time")
  };

  /* Populate guests dropdown (1–12) */
  for (let i = 1; i <= 12; i++) {
    fields.guests.add(new Option(i === 1 ? "1 guest" : `${i} guests`, i));
  }

  /* Time slots every 30 min from 12:00 pm to 10:30 pm */
  for (let m = 12 * 60; m <= 22 * 60 + 30; m += 30) {
    const h24 = Math.floor(m / 60);
    const min = m % 60;
    const label = `${h24 % 12 === 0 ? 12 : h24 % 12}:${String(min).padStart(2, "0")} ${h24 >= 12 ? "pm" : "am"}`;
    fields.time.add(new Option(label, `${String(h24).padStart(2, "0")}:${String(min).padStart(2, "0")}`));
  }

  /* Date bounds */
  const pad = (n) => String(n).padStart(2, "0");
  const toISO = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const today = new Date();
  const todayISO = toISO(today);
  const maxDate = new Date(today); maxDate.setDate(maxDate.getDate() + 90);
  fields.date.min = todayISO;
  fields.date.max = toISO(maxDate);

  const validators = {
    name(v) {
      if (!v) return "Enter your full name.";
      if (v.length < 2) return "Name must be at least 2 characters.";
      if (!/^[\p{L}][\p{L} .'-]*$/u.test(v)) return "Name can only contain letters, spaces, dots, hyphens and apostrophes.";
      return "";
    },
    email(v) {
      if (!v) return "Enter your email address.";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return "Enter a valid email address, like name@example.com.";
      return "";
    },
    phone(v) {
      if (!v) return "Enter your phone number.";
      if (!/^\+?[\d\s()-]+$/.test(v)) return "Phone number can only contain digits, spaces, + and hyphens.";
      const digits = v.replace(/\D/g, "");
      if (digits.length < 10 || digits.length > 13) return "Enter a phone number with 10 to 13 digits.";
      return "";
    },
    guests(v) { return !v ? "Select the number of guests." : ""; },
    date(v) {
      if (!v) return "Choose a reservation date.";
      if (v < todayISO) return "That date has passed. Choose today or a future date.";
      if (v > fields.date.max) return "Reservations open up to 90 days ahead.";
      return "";
    },
    time(v) {
      if (!v) return "Select a preferred time.";
      if (fields.date.value === todayISO) {
        const [h, mn] = v.split(":").map(Number);
        const now = new Date();
        if (h * 60 + mn <= now.getHours() * 60 + now.getMinutes()) return "That time has already passed. Choose a later time.";
      }
      return "";
    }
  };

  function validateField(key) {
    const el = fields[key];
    const message = validators[key](el.value.trim());
    const wrapper = el.closest(".field");
    const errorEl = document.getElementById(`${key}Error`);
    wrapper.classList.toggle("has-error", Boolean(message));
    if (errorEl) errorEl.textContent = message;
    if (message) {
      el.setAttribute("aria-invalid", "true");
      if (errorEl) el.setAttribute("aria-describedby", errorEl.id);
    } else {
      el.removeAttribute("aria-invalid");
      el.removeAttribute("aria-describedby");
    }
    return !message;
  }

  Object.keys(fields).forEach((key) => {
    const el = fields[key];
    el.addEventListener("blur", () => validateField(key));
    ["input", "change"].forEach((evt) =>
      el.addEventListener(evt, () => { if (el.closest(".field").classList.contains("has-error")) validateField(key); })
    );
  });
  fields.date.addEventListener("change", () => { if (fields.time.value) validateField("time"); });

  const requests = $("#requests");
  const charCount = $("#charCount");
  requests.addEventListener("input", () => { charCount.textContent = `${requests.value.length} / 300`; });

  function formatLongDate(iso) {
    const [y, mo, d] = iso.split("-").map(Number);
    return new Date(y, mo - 1, d).toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const results = Object.keys(fields).map((key) => [key, validateField(key)]);
    const firstInvalid = results.find(([, ok]) => !ok);

    if (firstInvalid) {
      fields[firstInvalid[0]].focus();
      showToast("Some details are missing or incorrect. Check the highlighted fields.", "error");
      return;
    }

    const guests = Number(fields.guests.value);
    const timeLabel = fields.time.options[fields.time.selectedIndex].text;
    const firstName = fields.name.value.trim().split(" ")[0];

    $("#confirmText").textContent =
      `Thank you, ${firstName}. We have a table for ${guests} ${guests === 1 ? "guest" : "guests"} on ${formatLongDate(fields.date.value)} at ${timeLabel}.`;

    form.hidden = true;
    confirmation.hidden = false;
    confirmation.focus();
    showToast("Reservation confirmed. We look forward to seeing you! 🪔", "success");
  });

  $("#newBooking").addEventListener("click", () => {
    form.reset();
    charCount.textContent = "0 / 300";
    $$(".field", form).forEach((f) => f.classList.remove("has-error"));
    $$(".error-msg", form).forEach((m) => { m.textContent = ""; });
    Object.values(fields).forEach((el) => { el.removeAttribute("aria-invalid"); el.removeAttribute("aria-describedby"); });
    confirmation.hidden = true;
    form.hidden = false;
    fields.name.focus();
  });

  /* ---------- Footer year ---------- */
  $("#year").textContent = new Date().getFullYear();
})();
